import { useState, useEffect } from "react";
import "./App.css";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";

function All(){
    const [spaceData, setSpaceData] = useState([]);
    useEffect(() => {
      const getArticle = async () => {
        try {
          const response = await axios.get(
            "https://api.spaceXdata.com/v3/launches?limit=100&launch_success=true&land_success=true&launch_year=2014");
          const myData = response.data;
          console.log(response.data);
          setSpaceData(myData);
        } catch (error) {
          console.log(error);
        }
      };
      getArticle();
    }, []);
    return(
        <div>

        </div>
    );
}
export default All;
