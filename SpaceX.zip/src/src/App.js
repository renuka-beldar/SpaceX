/* eslint-disable react/jsx-pascal-case */
import { useState, useEffect } from "react";
import "./App.css";
import axios from "axios";
import Launch_success_filter from "./Launch_success_filter";
import Launch_and_Land_filter from "./Launch_and_Land_filter";
import All from "./All";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  const [spaceData, setSpaceData] = useState([]);
  useEffect(() => {
    const getArticle = async () => {
      try {
        const response = await axios.get(
          "https://api.spaceXdata.com/v3/launches?limit=100"
        );
        const myData = response.data;
        console.log(response.data);
        setSpaceData(myData);
      } catch (error) {
        console.log(error);
      }
    };
    getArticle();
  }, []);
  return (
    <div className="container">
      <div className="row">
        <p>
          <b>SpaceX Launch Program</b>
        </p>
      </div>
      <div className="row">
        
        {spaceData.map((space, index) => {
          return (
          
            <div className="col-md-3 mt-5 card">
              <div key={index}>
                <img
                  className="mt-3 card-img-top"
                  src={Object.values(space.links.mission_patch_small)}
                  alt="images.."
                  // height="200px"
                  width="50px"
                />
                <br />
                <div style={{ color: "#4863A0" }}>
                  <b>{space.mission_name}</b>
                </div>
                <br />
                <b>Launch Year:</b>
                <div>{space.launch_year}</div>
                <br />
                <b>Mission_ids:</b>
                <div>{space.mission_id}</div>
                <br />
                <div>
                  <b>Successful Launch:</b>   
                  {space.launch_success.toString()}
                </div>
                <br />
                <b>Successful Landing:</b>
                <br />
                <br />
              </div>
            </div>
          );
        })}
      </div>

      <Launch_success_filter />
      <Launch_and_Land_filter />
      <All />
    </div>
  );
}

export default App;
